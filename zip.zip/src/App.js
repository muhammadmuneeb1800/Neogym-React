import "./App.scss";
import Routes from "./pages/Routes";
import "bootstrap/dist/js/bootstrap.bundle";

function App() {
  return (
    <div className="App">
      <Routes />
    </div>
  );
}

export default App;
